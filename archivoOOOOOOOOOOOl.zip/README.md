<div align="right">
<img width="32px" src="img/algo2.svg">
</div>

# TDA ABB


## Alumno: (Jerónimo Pérez Córdoba) - (111939) - (jeperezc@fi.uba.ar - jeroperez42@gmail.com)

- Para compilar:

```bash
gcc -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -O0 -g src/*.c main.c -o abb_app```

- Para ejecutar:

```compilar y ejecutar pruebas 
make run 
```

- Para ejecutar con valgrind:
```
make valgrind
```

```MAIN: estando en ABB-ENUNCIADO
./abb_app <archivo_csv> <comando>
```

---

##  Funcionamiento

El TDA ABB (Árbol Binario de Búsqueda) implementado en este TP es completamente genérico: puede almacenar cualquier tipo de puntero, y el criterio de orden lo define el usuario mediante una función de comparación pasada al crear el ABB.

---

## ABB_CREAR

-Objetivo: Crear un nuevo árbol binario de búsqueda vacío.

-Qué hace: Reserva memoria para la estructura principal y   guarda el puntero a la función de comparación que define el criterio de orden.

-Complejidad: O(1), porque solo reserva memoria y guarda punteros.
   
---
## ABB_INSERTAR 

-Objetivo: Insertar un elemento en el ABB.

-Qué hace: Busca la posición correcta según el comparador y agrega el elemento. Si el elemento ya existe, igualmente lo inserta (pueden existir duplicados).

-Complejidad: O(log n) promedio, O(n) peor caso, porque depende de la altura del árbol.

---
## ABB_BUSCAR 

-Objetivo: Buscar un elemento en el ABB.

-Qué hace: Recorre el árbol usando el comparador hasta encontrar el elemento o llegar a una hoja. Devuelve un puntero al dato o NULL si no está.

-Complejidad: O(log n) promedio, O(n) peor caso, porque recorre un solo camino desde la raíz.

<div align="center">
<img width="70%" src="img/BUSQUEDA.svg">
</div>

EXTRA: Utilizo buscar_nodo_y_padre(), una función auxiliar que implementé de forma iterativa. Usando el comparador, voy actualizando el puntero al nodo actual en cada paso, avanzando por el árbol hasta encontrar el dato buscado o determinar que no está presente en el ABB.

---
## ABB_EXISTE 

-Objetivo: Verificar si un elemento está en el ABB.

-Qué hace: Igual que abb_buscar, pero devuelve true/false.

-Complejidad: O(log n) promedio, O(n) peor caso, porque internamente busca igual que abb_buscar.

---
## ABB_ELIMINAR

-Objetivo: Eliminar un elemento del ABB.

-Qué hace: Busca el nodo a eliminar y lo quita del árbol. Si tiene dos hijos, lo reemplaza por el predecesor inorden.

-Complejidad: O(log n) promedio, O(n) peor caso, porque depende de la altura del árbol.

---
## ABB_RAIZ

-Objetivo: Obtener el dato almacenado en la raíz del ABB.

-Qué hace: Devuelve un puntero al dato de la raíz.

-Complejidad: O(1), porque es acceso directo a un puntero.

---
## ABB_ESTA_VACIO

-Objetivo: Verificar si el ABB está vacío.

-Qué hace: Devuelve true si la cantidad de elementos es 0.

-Complejidad: O(1), porque compara un contador.

---
## ABB_CON_CADA_ELEMENTO

-Objetivo: Recorrer el ABB aplicando una función a cada elemento.

-Qué hace: Recorre el árbol en el orden pedido (inorden, preorden, postorden) y ejecuta una función visitante para cada dato.

-Complejidad: O(n), porque visita todos los nodos una vez.


Tanto abb_con_cada_elemento como abb_vectorizar utilizan recorridos específicos para procesar el ABB de manera eficiente y predecible. El usuario puede elegir entre tres tipos de recorrido: inorden, preorden o postorden. En el siguiente diagrama se muestra cómo se almacenan los valores del ABB en un vector según el recorrido seleccionado.

-----
<div align="center">
<img width="70%" src="img/recorridos.svg">
</div>

---
## ABB_VECTORIZAR

-Objetivo: Copiar los elementos del ABB a un vector.

-Qué hace: Recorre el árbol en el orden pedido y copia los punteros a un vector.

-Complejidad: O(n), porque recorre todos los nodos para copiarlos.

---
## ABB_DESTRUIR
-Objetivo: Liberar toda la memoria usada por el ABB.

-Qué hace: Libera todos los nodos del árbol, pero no los datos almacenados.

-Complejidad: O(n), porque libera cada nodo una vez.

---
## ABB_DESTRUIR_TODO

-Objetivo: Liberar toda la memoria del ABB y de los datos almacenados.

-Qué hace: Igual que abb_destruir, pero además llama a una función destructora para cada dato.

-Complejidad: O(n), porque recorre y destruye todos los nodos y datos.

---

## Respuestas a las preguntas teóricas

¿Qué es un árbol, un árbol binario y un árbol binario de búsqueda?
  Árbol:
    Un árbol es una estructura de datos jerárquica compuesta por nodos. Cada nodo puede tener cero o más hijos, y existe un único nodo raíz desde el cual se puede llegar a cualquier otro nodo del árbol. No hay un orden específico entre los hijos.

  Árbol binario:
    Un árbol binario es un tipo especial de árbol donde cada nodo puede tener como máximo dos hijos, denominados hijo izquierdo e hijo derecho.

  Árbol binario de búsqueda (ABB):
    Un árbol binario de búsqueda es un árbol binario en el que, para cada nodo, todos los valores del subárbol izquierdo son menores y todos los valores del subárbol derecho son mayores. Esto permite búsquedas, inserciones y eliminaciones eficientes. 

<div align="center">
<img width="70%" src="img/ARBOLES.svg">
</div>


---

## Recursividad e iteratividad:

La recursividad fue fundamental en varias funciones, especialmente en aquellas que recorren el árbol completo, como abb_destruir_nodos, abb_destruir_con_destructor, y los recorridos (abb_recorrer). Por ejemplo, para destruir todos los nodos, simplemente llamo recursivamente a la función sobre los hijos izquierdo y derecho antes de liberar el nodo actual.

En cambio, tanto en la inserción (abb_insertar) como en la búsqueda (abb_buscar), implementé el recorrido del árbol de forma iterativa, usando bucles y punteros auxiliares en vez de recursión. Esto me permitió manejar de manera más sencilla los punteros a los padres de cada nodo, algo fundamental para la eliminación, y además evita posibles problemas de desbordamiento de pila si el árbol está muy desbalanceado.

## Manejo de nodos y punteros:

El manejo de punteros fue uno de los principales desafíos, sobre todo al eliminar nodos. Fue necesario distinguir entre eliminar la raíz, una hoja, un nodo con un solo hijo o con dos hijos. Para el caso de dos hijos, se reemplaza el nodo por su predecesor inorden, lo que requiere encontrar y desvincular ese nodo correctamente. Además, siempre me aseguré de actualizar los punteros de los padres y de liberar la memoria de los nodos eliminados para evitar fugas.

Para la destrucción total (abb_destruir_todo), permito que el usuario pase una función destructora para liberar correctamente los datos almacenados, ya que el ABB solo conoce los punteros y no el contenido.

En línea general, el caso más difícil fue la eliminación de nodos, pero al hacerla por partes separadas se me hizo más fácil que plantear una versión completa y luego modularizarla.

---